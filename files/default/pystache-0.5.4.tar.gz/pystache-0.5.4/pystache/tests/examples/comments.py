
"""
TODO: add a docstring.

"""

class Comments(object):

    def title(self):
        return "A Comedy of Errors"
