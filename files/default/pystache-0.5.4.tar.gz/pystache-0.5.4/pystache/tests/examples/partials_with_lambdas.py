
"""
TODO: add a docstring.

"""

from pystache.tests.examples.lambdas import rot

class PartialsWithLambdas(object):

    def rot(self):
        return rot
